//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vncviewer.rc
//
#define IDR_MANIFEST                    1
#define IDI_ICON                        101

