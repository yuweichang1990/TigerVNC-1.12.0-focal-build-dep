//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winvnc.rc
//
#define IDR_MANIFEST                    1
#define IDI_ICON                        101
#define IDR_TRAY                        102
#define IDD_DIALOG1                     103
#define IDD_ABOUT                       104
#define IDI_CONNECTED                   105
#define IDD_QUERY_CONNECT               107
#define IDD_ADD_NEW_CLIENT              108
#define IDB_BITMAP                      109
#define IDD_CONTROL_PANEL               110
#define IDI_ICON_DISABLE                111
#define IDI_CONNECTED_DISABLE           112
#define IDC_DESCRIPTION                 1000
#define IDC_BUILDTIME                   1001
#define IDC_VERSION                     1002
#define IDC_COPYRIGHT                   1003
#define IDC_QUERY_COUNTDOWN             1008
#define IDC_QUERY_USER                  1009
#define IDC_QUERY_HOST                  1010
#define IDC_HOST                        1011
#define IDC_LIST_CONNECTIONS            1012
#define IDC_STATIC_KLIENTS_LIST         1013
#define IDC_STATIC_SELECTED_KLIENTS     1014
#define IDC_VIEW_ONLY                   1015
#define IDC_FULL_CONTROL                1016
#define IDC_STOP_UPDATE                 1017
#define IDC_KILL_SEL_CLIENT             1018
#define IDC_PROPERTIES                  1019
#define IDC_ADD_CLIENT                  1020
#define IDC_KILL_ALL                    1021
#define IDC_DISABLE_CLIENTS             1022
#define ID_CONTR0L_PANEL                40001
#define ID_CLOSE                        40002
#define ID_ABOUT                        40003
#define ID_DISCONNECT                   40004
#define ID_CONNECT                      40005
#define ID_OPTIONS                      40006
#define ID_DISABLE_NEW_CLIENTS          40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
